#!/bin/bash
cd "$(dirname "$0")"
if ! command -v docker >/dev/null 2>&1; then
  echo "Docker Desktop is required."
  echo "Install it from https://www.docker.com/products/docker-desktop/ then double-click again."
  read -p "Press Return to close."
  exit 1
fi
echo "Building and starting the container (first run takes a few minutes)..."
( sleep 5 && open http://127.0.0.1:5000 ) &
docker compose up --build
