@echo off
title OTQ Dashboard (Docker)
cd /d "%~dp0"
where docker >nul 2>nul
if errorlevel 1 (
  echo Docker Desktop is required.
  echo Install it from https://www.docker.com/products/docker-desktop/ then double-click again.
  pause
  exit /b
)
echo Building and starting the container (first run takes a few minutes)...
start "" http://127.0.0.1:5000
docker compose up --build
pause
