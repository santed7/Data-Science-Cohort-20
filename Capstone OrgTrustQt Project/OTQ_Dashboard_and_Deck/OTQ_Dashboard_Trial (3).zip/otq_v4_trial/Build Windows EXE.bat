@echo off
title Build OTQ Dashboard EXE
cd /d "%~dp0"
echo ============================================================
echo   Building a standalone Windows app:  OTQ-Dashboard.exe
echo   (One-time build. Needs Python 3 installed.)
echo ============================================================
echo.
where python >nul 2>nul
if errorlevel 1 (
  echo Python 3 is not installed.
  echo Install it from https://www.python.org/downloads/ and TICK "Add Python to PATH",
  echo then double-click this file again.
  echo.
  pause
  exit /b
)
echo Installing build tools (first time, a few minutes)...
python -m pip install --quiet --upgrade pip
python -m pip install --quiet pyinstaller flask pandas scikit-learn matplotlib
echo.
echo Building... this can take several minutes. Please wait.
python -m PyInstaller --noconfirm --onefile --name OTQ-Dashboard ^
  --add-data "templates;templates" ^
  --add-data "sample_data;sample_data" ^
  --collect-all sklearn ^
  --collect-all scipy ^
  app.py
echo.
if exist "dist\OTQ-Dashboard.exe" (
  echo ============================================================
  echo   DONE.  Your standalone app is here:
  echo       dist\OTQ-Dashboard.exe
  echo.
  echo   Double-click that .exe anytime - no Python needed to run.
  echo   It opens the dashboard in your browser automatically.
  echo ============================================================
) else (
  echo Build did not produce the exe. Scroll up for the error message.
)
echo.
pause
