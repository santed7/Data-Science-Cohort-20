@echo off
title OTQ Dashboard
cd /d "%~dp0"
echo ============================================
echo   Organizational Trust Quotient - Dashboard
echo ============================================
echo.
where python >nul 2>nul
if errorlevel 1 (
  echo Python is not installed.
  echo Please install Python 3 from https://www.python.org/downloads/
  echo During install, TICK "Add Python to PATH". Then double-click this file again.
  echo.
  pause
  exit /b
)
if not exist venv (
  echo First-time setup ^(one time, ~1-2 min^)...
  python -m venv venv
)
call venv\Scripts\activate.bat
python -m pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt
set OTQ_OPEN_BROWSER=1
echo.
echo Opening the dashboard in your browser at http://127.0.0.1:5000
echo Keep this window OPEN while you use it. Close it to stop.
echo.
python app.py
pause
