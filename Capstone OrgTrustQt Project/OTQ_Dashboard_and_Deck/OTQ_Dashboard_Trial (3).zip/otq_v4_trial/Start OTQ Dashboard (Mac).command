#!/bin/bash
cd "$(dirname "$0")"
echo "============================================"
echo "  Organizational Trust Quotient - Dashboard"
echo "============================================"
echo
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is not installed."
  echo "Install it from https://www.python.org/downloads/ then double-click this file again."
  read -p "Press Return to close."
  exit 1
fi
if [ ! -d venv ]; then
  echo "First-time setup (one time, ~1-2 min)..."
  python3 -m venv venv
fi
source venv/bin/activate
python -m pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt
export OTQ_OPEN_BROWSER=1
echo
echo "Opening the dashboard in your browser at http://127.0.0.1:5000"
echo "Keep this window OPEN while you use it. Close it to stop."
echo
python app.py
