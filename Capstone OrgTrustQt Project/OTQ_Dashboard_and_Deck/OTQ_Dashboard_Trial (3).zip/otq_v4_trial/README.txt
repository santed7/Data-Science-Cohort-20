FREE 15-DAY TRIAL
=================
This build runs free for 15 days from the first time it is opened on a
machine. While the trial is active, a thin banner at the very top shows
"Free demo - N days left - Convert to paid". After 15 days the dashboard
locks and shows a "convert to paid" page instead.

- The clock is stored PER-USER, outside the app folder, so re-copying or
  re-downloading the app does not reset it. It works the same for the
  one-file .exe and the faster-start folder app.
- To convert: https://organizationaltrustquotient.com/buy
  or email vernon@organizationaltrustquotient.com
- A computer-only trial can be bypassed by a determined technical user;
  for real protection a short online license check is the next step.


NEW in this version — engagement status
---------------------------------------
The dashboard now shows, at the top, a 5-level ENGAGEMENT STATUS banner
(Thriving / Healthy / Watch / At-risk / Critical) based on median reply time
and its recent trend, plus a "Least-engaged channels" table flagging the
quietest channels. Both are clearly labeled an engagement/responsiveness
signal — NOT a validated trust score.

OTQ DASHBOARD — quick troubleshooting
=====================================
If the app window is BLACK and just sits there:
  - First launch of the single-file .exe UNPACKS scikit-learn/scipy and can
    take 30-90 seconds. Wait for the line "Open this in your browser: ...".
  - If the browser does not open by itself, open Chrome to  http://localhost:5000
  - For a MUCH faster start, rebuild with "Build Windows EXE (faster start).bat".
    That makes a folder app at  dist\OTQ-Dashboard\OTQ-Dashboard.exe  which opens
    in a couple of seconds (it does not unpack each time). Keep that folder intact;
    make a Desktop shortcut to the .exe inside it.
  - If it stays blank with NO text after ~2 min, run
    "Start OTQ Dashboard (Windows).bat" to see the error message.

OTQ DASHBOARD — Apostles edition (Windows)
==========================================

The Apostles data is built in. Nothing to upload — start it and the results
appear in your web browser.

==================================================================
OPTION 1 — TRUE STANDALONE .EXE  (needs nothing installed to RUN)
==================================================================
You build it ONCE, then it's a plain double-click app forever.

  STEP 1 (one time): install Python 3 from https://www.python.org/downloads/
          During install, TICK the box "Add Python to PATH".

  STEP 2 (one time): double-click   "Build Windows EXE.bat"
          It downloads the tools and builds the app (a few minutes).
          When it finishes you'll have:   dist\OTQ-Dashboard.exe

  STEP 3 (every time after): double-click   dist\OTQ-Dashboard.exe
          No Python needed to run it. A small window opens and your browser
          shows the dashboard automatically. Close that window to stop.

  You can copy OTQ-Dashboard.exe anywhere (Desktop, USB stick, another PC)
  and it runs on its own.

==================================================================
OPTION 2 — DOUBLE-CLICK STARTER  (no build step; needs Python)
==================================================================
  Double-click   "Start OTQ Dashboard (Windows).bat"
  It sets up the first time, then opens the dashboard in your browser.

==================================================================
OPTION 3 — CONTAINER (like Docker)
==================================================================
  With Docker Desktop installed, double-click "Start with Docker (Windows).bat"
  or run:  docker compose up --build   then open http://127.0.0.1:5000

------------------------------------------------------------------
How to STOP it
------------------------------------------------------------------
Close the small black window that opened (Options 1 & 2), or press Ctrl+C /
quit Docker Desktop (Option 3).

------------------------------------------------------------------
What's inside / what was fixed
------------------------------------------------------------------
- Bundled data: sample_data\{slack,teams,outlook}_apostles_All.csv
- "/" auto-runs the bundled sample; "Use my files" still accepts your own CSVs.
- Outlook duration bug fixed (it ignored the "end" column -> NaN scores).
- Verified end-to-end: 1250 events -> 154 modeled days, Test R2 ~0.14,
  MAE ~98 min, three charts, page returns HTTP 200, no errors.

Files: app.py, otq_pipeline.py, templates\index.html, sample_data\,
requirements.txt, Build Windows EXE.bat, the Start... launchers,
Dockerfile, docker-compose.yml.
