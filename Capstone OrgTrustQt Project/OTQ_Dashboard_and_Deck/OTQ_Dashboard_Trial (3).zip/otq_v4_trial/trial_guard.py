"""
trial_guard.py  --  15-day free-trial gate for the OTQ Dashboard.

Drop this file next to app.py and add three lines to app.py:

    from trial_guard import init_trial

    app = Flask(__name__)
    init_trial(app)                      # <-- one line, after the app is created

That's it. The dashboard now runs for 15 days from first launch, shows a small
countdown banner, and after the trial ends it locks the analysis routes and
shows a "convert to paid" page instead.

No new dependencies -- this uses only the Python standard library, so your
requirements.txt and the PyInstaller EXE build are unchanged.

----------------------------------------------------------------------------
HONEST LIMITATION (worth knowing, not worth hiding):
A trial that runs entirely on the client's machine can always be bypassed by a
determined, technical user (editing the clock, finding and deleting the state
file, decompiling the EXE). This module stops *casual* resets -- the state file
is signed so it can't be hand-edited, it's stored outside the app folder so
re-downloading the app doesn't reset it, and rolling the system clock backward
is detected and treated as an expired trial. For real revenue protection you
want a short server-side license check; ask Claude to add that as a next step.
----------------------------------------------------------------------------
"""

import os
import sys
import json
import hmac
import base64
import hashlib
import datetime as _dt
from pathlib import Path

from flask import request, render_template_string, abort

# ---------------------------------------------------------------------------
# Configuration -- change these for your offer.
# ---------------------------------------------------------------------------
DEFAULTS = {
    "trial_days": 15,
    "product_name": "OTQ Dashboard",
    "company": "SanTed Quantum Scheduling",
    "purchase_url": "https://organizationaltrustquotient.com/buy",
    "contact_email": "vernon@organizationaltrustquotient.com",
    # Clock-rollback tolerance: if the system clock appears to go backward by
    # more than this many days vs. what we last saw, we treat it as tampering.
    "rollback_tolerance_days": 1,
    # Routes that stay reachable even after the trial ends (so the expired
    # page can load its own assets and you can still hit a health check).
    "always_allow_prefixes": ("/static", "/trial", "/health", "/favicon.ico"),
}

# A per-build secret used to sign the trial-state file so it can't be
# hand-edited. Anyone who decompiles the app can extract it -- that's expected;
# the goal is to stop casual edits, not to be uncrackable. Change it per build
# if you want old state files to be rejected by new builds.
_SECRET = b"OTQ-trial-v1-3f9a1c7e-change-me-per-build"

_ISO = "%Y-%m-%dT%H:%M:%S"


# ---------------------------------------------------------------------------
# State storage -- lives in the OS per-user data dir, NOT the app folder, so
# re-downloading / re-extracting the app does not reset the trial.
# ---------------------------------------------------------------------------
def _state_dir(product_name: str) -> Path:
    safe = "".join(c for c in product_name if c.isalnum()) or "OTQDashboard"
    if sys.platform.startswith("win"):
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    elif sys.platform == "darwin":
        base = os.path.expanduser("~/Library/Application Support")
    else:
        base = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")
    d = Path(base) / safe
    d.mkdir(parents=True, exist_ok=True)
    return d


def _state_path(product_name: str) -> Path:
    # Slightly opaque filename so it isn't obvious at a glance.
    return _state_dir(product_name) / ".otqlic"


def _sign(payload: dict) -> str:
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return base64.b64encode(hmac.new(_SECRET, raw, hashlib.sha256).digest()).decode()


def _now() -> _dt.datetime:
    return _dt.datetime.utcnow().replace(microsecond=0)


def _read_state(path: Path):
    try:
        blob = json.loads(path.read_text(encoding="utf-8"))
        data = blob["data"]
        if not hmac.compare_digest(_sign(data), blob.get("sig", "")):
            return None, "tampered"          # signature mismatch
        return data, None
    except FileNotFoundError:
        return None, "missing"
    except Exception:
        return None, "tampered"              # unparseable / corrupted


def _write_state(path: Path, data: dict):
    blob = {"data": data, "sig": _sign(data)}
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(blob, separators=(",", ":")), encoding="utf-8")
    tmp.replace(path)


# ---------------------------------------------------------------------------
# Core evaluation: returns a dict describing trial status for this request.
# ---------------------------------------------------------------------------
def _evaluate(cfg: dict) -> dict:
    path = _state_path(cfg["product_name"])
    now = _now()
    data, problem = _read_state(path)

    if problem == "missing":
        # First ever launch on this machine -> start the clock.
        data = {
            "first_run": now.strftime(_ISO),
            "last_seen": now.strftime(_ISO),
            "trial_days": cfg["trial_days"],
            "v": 1,
        }
        _write_state(path, data)
    elif problem == "tampered":
        # File edited, corrupted, or made by a different build. Fail closed.
        return {"active": False, "reason": "tampered", "days_left": 0}

    first_run = _dt.datetime.strptime(data["first_run"], _ISO)
    last_seen = _dt.datetime.strptime(data["last_seen"], _ISO)
    trial_days = int(data.get("trial_days", cfg["trial_days"]))

    # Clock-rollback detection: now should never be far behind last_seen.
    tol = _dt.timedelta(days=cfg["rollback_tolerance_days"])
    if now < last_seen - tol:
        return {"active": False, "reason": "clock_rollback", "days_left": 0}

    # Move the high-water mark forward only.
    if now > last_seen:
        data["last_seen"] = now.strftime(_ISO)
        _write_state(path, data)

    elapsed = now - first_run
    days_used = elapsed.days
    days_left = trial_days - days_used

    if days_left <= 0:
        return {"active": False, "reason": "expired", "days_left": 0}

    return {
        "active": True,
        "reason": "ok",
        "days_left": days_left,
        "first_run": data["first_run"],
    }


# ---------------------------------------------------------------------------
# Branded pages (inline so there is no extra template file to misplace).
# ---------------------------------------------------------------------------
_PALETTE = {
    "navy": "#11243F", "teal": "#028090", "sea": "#00A896",
    "mint": "#02C39A", "ice": "#EAF2F6",
}

_EXPIRED_PAGE = """<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{ product }} — Trial ended</title>
<style>
  :root{ --navy:{{p.navy}}; --teal:{{p.teal}}; --sea:{{p.sea}};
         --mint:{{p.mint}}; --ice:{{p.ice}}; }
  *{box-sizing:border-box} body{margin:0;font-family:Arial,Helvetica,sans-serif;
    background:var(--ice);color:var(--navy);min-height:100vh;display:flex;
    align-items:center;justify-content:center;padding:24px}
  .card{background:#fff;max-width:560px;width:100%;border-radius:16px;
    box-shadow:0 12px 40px rgba(17,36,63,.15);overflow:hidden}
  .top{background:linear-gradient(135deg,var(--navy),var(--teal));
    color:#fff;padding:32px 32px 26px}
  h1{font-family:Georgia,'Times New Roman',serif;margin:0 0 6px;font-size:24px}
  .sub{opacity:.85;font-size:14px}
  .body{padding:28px 32px 32px}
  p{line-height:1.55;margin:0 0 16px}
  .cta{display:inline-block;background:var(--sea);color:#fff;text-decoration:none;
    font-weight:bold;padding:13px 22px;border-radius:10px;margin:6px 8px 6px 0}
  .cta.alt{background:#fff;color:var(--teal);border:2px solid var(--teal)}
  .foot{font-size:12px;color:#5b6b7d;margin-top:18px}
  .reason{font-size:12px;color:#8a98a8;margin-top:14px}
</style></head>
<body><div class="card">
  <div class="top">
    <h1>Your {{ product }} trial has ended</h1>
    <div class="sub">Thank you for trying the {{ days }}-day free demo.</div>
  </div>
  <div class="body">
    <p>The demo gave you full access to the {{ product }} engagement-analysis
       pipeline for {{ days }} days. To keep analyzing your team's
       communication data, upgrade to a licensed copy.</p>
    <a class="cta" href="{{ purchase_url }}">Convert to a paid plan</a>
    <a class="cta alt" href="mailto:{{ contact_email }}?subject={{ product }}%20license">
       Talk to us</a>
    <p class="foot">{{ company }} &middot; {{ contact_email }}</p>
    {% if reason in ('tampered','clock_rollback') %}
    <p class="reason">Note: the trial record on this machine could not be
       verified, so access is locked. Contact us if you believe this is an
       error.</p>
    {% endif %}
  </div>
</div></body></html>"""

_BANNER = """
<div id="otq-trial-banner" style="position:fixed;top:0;left:0;right:0;z-index:9999;
  font:13px/1.4 Arial,Helvetica,sans-serif;background:{navy};color:#fff;
  padding:8px 14px;text-align:center">
  <strong>Free demo</strong> &middot; {days} day{plural} left &middot;
  <a href="{purchase_url}" style="color:{mint};font-weight:bold;text-decoration:underline">
  Convert to paid</a>
  <span onclick="this.parentNode.style.display='none'"
    style="cursor:pointer;float:right;opacity:.7">&times;</span>
</div>
<div style="height:34px"></div>
"""


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def init_trial(app, **overrides):
    """Attach the 15-day trial gate to a Flask app.

    Usage:  init_trial(app)
            init_trial(app, trial_days=15,
                       purchase_url="https://...", contact_email="...")
    """
    cfg = dict(DEFAULTS)
    cfg.update(overrides)

    @app.before_request
    def _trial_gate():
        p = request.path or "/"
        if any(p.startswith(pre) for pre in cfg["always_allow_prefixes"]):
            return None
        status = _evaluate(cfg)
        request.otq_trial = status            # available to your views if wanted
        if not status["active"]:
            html = render_template_string(
                _EXPIRED_PAGE, product=cfg["product_name"], days=cfg["trial_days"],
                purchase_url=cfg["purchase_url"], contact_email=cfg["contact_email"],
                company=cfg["company"], reason=status["reason"], p=_PALETTE,
            )
            return html, 200                  # 200 so it renders cleanly
        return None

    @app.after_request
    def _inject_banner(response):
        status = getattr(request, "otq_trial", None)
        if (status and status.get("active")
                and response.content_type
                and response.content_type.startswith("text/html")):
            try:
                body = response.get_data(as_text=True)
                if "</body>" in body and "otq-trial-banner" not in body:
                    days = status["days_left"]
                    banner = _BANNER.format(
                        days=days, plural="" if days == 1 else "s",
                        purchase_url=cfg["purchase_url"],
                        navy=_PALETTE["navy"], mint=_PALETTE["mint"],
                    )
                    response.set_data(body.replace("</body>", banner + "</body>"))
            except Exception:
                pass                          # never let the banner break a page
        return response

    # A tiny status endpoint, handy for testing and for a "days left" call.
    @app.route("/trial/status")
    def _trial_status():
        from flask import jsonify
        return jsonify(_evaluate(cfg))

    return app
