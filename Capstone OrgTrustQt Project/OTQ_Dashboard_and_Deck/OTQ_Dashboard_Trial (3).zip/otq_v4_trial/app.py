"""
OTQ Dashboard — Apostles edition.

Restructured so the bundled Apostles dataset runs end-to-end with NO upload
step: visiting "/" (or "/sample") loads the three CSVs that ship in
sample_data/ and renders the results immediately. You can still upload your
own Slack / Teams / Outlook exports to replace the sample.

Run:
    pip install flask pandas scikit-learn matplotlib
    python app.py
    # open http://127.0.0.1:5000/
"""

import os
import sys

from flask import Flask, render_template, request

from otq_pipeline import run_otq_pipeline, run_otq_pipeline_from_paths
from trial_guard import init_trial  # 15-day free-trial gate

# When packaged by PyInstaller (--onefile), bundled files are unpacked to a
# temporary folder exposed as sys._MEIPASS. Fall back to this file's folder
# when running normally.
RES_DIR = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))

app = Flask(__name__, template_folder=os.path.join(RES_DIR, "templates"))

# ── 15-day free trial ────────────────────────────────────────────────────────
# Runs free for 15 days from first launch, shows a countdown banner, then locks
# the dashboard behind a "convert to paid" page. Stored per-user outside the app
# folder, so it survives re-copying the app and works for both the one-file and
# the faster-start (folder) builds.
init_trial(
    app,
    trial_days=15,
    product_name="OTQ Dashboard",
    company="SanTed Quantum Scheduling",
    purchase_url="https://organizationaltrustquotient.com/buy",
    contact_email="vernon@organizationaltrustquotient.com",
)
# ─────────────────────────────────────────────────────────────────────────────

# ── Bundled Apostles sample (no upload required) ─────────────────────────────
SAMPLE_DIR = os.path.join(RES_DIR, "sample_data")
SAMPLE_FILES = [
    os.path.join(SAMPLE_DIR, name)
    for name in (
        "slack_apostles_All.csv",
        "teams_apostles_All.csv",
        "outlook_apostles_All.csv",
    )
]


def _run_sample():
    """Run the pipeline on the bundled Apostles CSVs."""
    present = [p for p in SAMPLE_FILES if os.path.exists(p)]
    if not present:
        raise FileNotFoundError(
            "Bundled sample CSVs not found in sample_data/. Expected "
            "slack_apostles_All.csv, teams_apostles_All.csv, outlook_apostles_All.csv."
        )
    return run_otq_pipeline_from_paths(present)


@app.route("/", methods=["GET"])
def index():
    # Auto-run the bundled Apostles sample so results show on first load.
    try:
        result = _run_sample()
        return render_template("index.html", result=result, source_label="Apostles sample (bundled)")
    except Exception as exc:  # never crash the page — show the message instead
        return render_template("index.html", error=str(exc))


@app.route("/sample", methods=["GET"])
def sample():
    try:
        result = _run_sample()
        return render_template("index.html", result=result, source_label="Apostles sample (bundled)")
    except Exception as exc:
        return render_template("index.html", error=str(exc))


@app.route("/predict", methods=["POST"])
def predict():
    files = request.files.getlist("files")
    if not files or all(getattr(f, "filename", "") == "" for f in files):
        # Fall back to the bundled sample instead of erroring out.
        try:
            result = _run_sample()
            return render_template(
                "index.html",
                result=result,
                source_label="Apostles sample (bundled)",
                notice="No file chosen — showing the bundled Apostles sample.",
            )
        except Exception as exc:
            return render_template("index.html", error=str(exc))

    try:
        result = run_otq_pipeline(files)
    except Exception as exc:
        return render_template("index.html", error=str(exc))

    names = ", ".join(getattr(f, "filename", "") for f in files if getattr(f, "filename", ""))
    return render_template("index.html", result=result, source_label="Your upload: " + names)


if __name__ == "__main__":
    import socket
    import threading
    import webbrowser

    def _free_port(preferred):
        """Use 5000 if free, otherwise grab any open port so launch never fails."""
        try:
            s = socket.socket()
            s.bind(("127.0.0.1", preferred))
            s.close()
            return preferred
        except OSError:
            s = socket.socket()
            s.bind(("127.0.0.1", 0))
            p = s.getsockname()[1]
            s.close()
            return p

    port = _free_port(int(os.environ.get("PORT", "5000")))
    url = f"http://127.0.0.1:{port}"

    print("=" * 58, flush=True)
    print("  OTQ Dashboard is starting...", flush=True)
    print(f"  Open this in your browser:   {url}", flush=True)
    print("  (Keep this window OPEN. Close it to stop the dashboard.)", flush=True)
    print("=" * 58, flush=True)

    if getattr(sys, "frozen", False) or os.environ.get("OTQ_OPEN_BROWSER", "") == "1":
        threading.Timer(2.5, lambda: webbrowser.open(url)).start()

    app.run(host="0.0.0.0", port=port, debug=False)

