@echo off
title Build OTQ Dashboard (faster start)
cd /d "%~dp0"
echo ============================================================
echo   Building OTQ Dashboard (FASTER START - folder version)
echo   This version does NOT unpack on every launch, so it
echo   opens in a couple of seconds instead of a long black wait.
echo ============================================================
echo.
where python >nul 2>nul
if errorlevel 1 (
  echo Python 3 is not installed. Get it from https://www.python.org/downloads/
  echo TICK "Add Python to PATH", then run this again.
  pause & exit /b
)
python -m pip install --quiet --upgrade pip
python -m pip install --quiet pyinstaller flask pandas scikit-learn matplotlib
echo Building... please wait (a few minutes).
python -m PyInstaller --noconfirm --onedir --name OTQ-Dashboard ^
  --add-data "templates;templates" ^
  --add-data "sample_data;sample_data" ^
  --collect-all sklearn ^
  --collect-all scipy ^
  app.py
echo.
if exist "dist\OTQ-Dashboard\OTQ-Dashboard.exe" (
  echo ============================================================
  echo   DONE. Run the app by double-clicking:
  echo       dist\OTQ-Dashboard\OTQ-Dashboard.exe
  echo   (Keep the WHOLE "OTQ-Dashboard" folder together. To put a
  echo    shortcut on your Desktop: right-click the .exe -^> Send to
  echo    -^> Desktop ^(create shortcut^).)
  echo ============================================================
) else (
  echo Build did not produce the app. Scroll up for the error and send it to me.
)
echo.
pause
