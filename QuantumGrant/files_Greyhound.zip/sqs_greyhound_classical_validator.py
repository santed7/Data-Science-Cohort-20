"""
SQS Greyhound POC — Classical Validator
========================================

Runs the exact same network-schedule QUBO as sqs_greyhound_network_poc.py,
but using D-Wave's classical simulated annealing sampler instead of quantum
hardware.

Purpose:
  - Validate QUBO formulation correctness BEFORE burning quantum compute
  - Run offline (no Leap account required) for rapid iteration
  - Establish the classical baseline for the Q2 benchmark milestone

Requirements:
  pip install dwave-ocean-sdk
"""

from dwave.samplers import SimulatedAnnealingSampler
from sqs_greyhound_network_poc import (
    CANDIDATE_ROUTES,
    CITIES,
    MINIMUM_COVERAGE,
    AVAILABLE_BUSES,
    build_network_schedule_bqm,
    interpret_solution,
    evaluate_solution,
    print_report,
)


def solve_classical(bqm, num_reads=1000):
    sampler = SimulatedAnnealingSampler()
    sampleset = sampler.sample(bqm, num_reads=num_reads)
    return sampleset


if __name__ == "__main__":
    print("=" * 70)
    print("SQS Greyhound POC — Classical Validator (simulated annealing)")
    print("=" * 70)
    print(f"Cities: {len(CITIES)}, Route-times: {len(CANDIDATE_ROUTES)}, "
          f"Coverage pairs: {len(MINIMUM_COVERAGE)}, Fleet: {AVAILABLE_BUSES}")
    print()

    bqm = build_network_schedule_bqm()
    print(f"BQM: {len(bqm.variables)} variables, "
          f"{len(bqm.quadratic)} quadratic interactions")
    print()

    print("Running classical simulated annealing (no Leap required)...")
    sampleset = solve_classical(bqm, num_reads=1000)
    print(f"Completed {len(sampleset)} samples.")
    print()

    best = sampleset.first
    scheduled, dropped = interpret_solution(best.sample)
    metrics = evaluate_solution(scheduled)

    print("Best schedule (classical):")
    print("-" * 70)
    print_report(scheduled, dropped, metrics, best.energy)

    print()
    print("Next step: run sqs_greyhound_network_poc.py against D-Wave hardware.")
