"""
SQS Proof of Concept — Greyhound Network Schedule Optimization (Small Scale)
==============================================================================

A minimal, runnable example showing how SanTed Quantum Scheduling (SQS)
formulates a network-wide scheduling decision as a QUBO and solves it on
D-Wave quantum annealing hardware via the Leap cloud platform.

Business problem:
  Greyhound operates a regional subnetwork. For each day, management must
  decide which of several candidate route-times to actually run, subject to:

    - Fleet availability: only N buses available
    - Minimum service: every city pair must be served at least once per day
    - Driver availability: only M drivers available per time slot
    - Revenue vs. cost: maximize expected revenue minus operating cost

  This is the network-level "which route-times run today" decision.
  Individual bus and driver assignments are downstream of this choice.

Scope note:
  This is a PROOF OF CONCEPT at 5 cities and ~16 candidate route-times.
  Real Greyhound network scheduling involves 200+ cities, thousands of
  candidate route-times, and continuous demand curves. The QUBO pattern
  demonstrated here scales to D-Wave's hybrid CQM solver — the Q2 and Q3
  work on the NMQTA grant. The current hardware cannot solve the full
  network problem in one pass; SQS's approach decomposes the full network
  into regional subnetworks of the size modeled here.

Requirements:
  pip install dwave-ocean-sdk
  dwave setup     (one-time: configures your Leap API token)

Expected runtime: ~5 seconds on D-Wave Advantage QPU via Leap.
"""

import dimod


# ----------------------------------------------------------------------
# Step 1 — Define the business problem
# ----------------------------------------------------------------------
# A small regional subnetwork. Each "route" is a directed city pair.
# Real Greyhound has ~2,400 city pairs; we use 5 cities = 10 directed pairs
# but model only a subset that have meaningful demand.

CITIES = ["Dallas", "Austin", "Houston", "San Antonio", "Oklahoma City"]

# Candidate route-times: each is (origin, destination, departure_hour)
# A scheduling decision means choosing a subset of these to actually run.
# In practice these are generated from a timetable planning system.
CANDIDATE_ROUTES = {
    "r01": ("Dallas",        "Austin",        6),
    "r02": ("Dallas",        "Austin",        14),
    "r03": ("Austin",        "Dallas",        9),
    "r04": ("Austin",        "Dallas",        17),
    "r05": ("Dallas",        "Houston",       7),
    "r06": ("Dallas",        "Houston",       15),
    "r07": ("Houston",       "Dallas",        8),
    "r08": ("Houston",       "Dallas",        16),
    "r09": ("Austin",        "San Antonio",   10),
    "r10": ("San Antonio",   "Austin",        13),
    "r11": ("Houston",       "San Antonio",   11),
    "r12": ("San Antonio",   "Houston",       14),
    "r13": ("Dallas",        "Oklahoma City", 9),
    "r14": ("Oklahoma City", "Dallas",        13),
    "r15": ("Austin",        "Houston",       12),
    "r16": ("Houston",       "Austin",        8),
}

# Expected revenue per route-time, based on historical demand forecasting.
# Values in dollars. Real figures would come from Greyhound's revenue
# management system; these are illustrative.
EXPECTED_REVENUE = {
    "r01": 1800, "r02": 2100, "r03": 1950, "r04": 2200,
    "r05": 2400, "r06": 2800, "r07": 2300, "r08": 2600,
    "r09":  900, "r10":  850, "r11": 1100, "r12": 1050,
    "r13": 1400, "r14": 1350, "r15": 1250, "r16": 1200,
}

# Operating cost per route-time (fuel, driver hours, terminal fees).
OPERATING_COST = {
    "r01": 1200, "r02": 1200, "r03": 1200, "r04": 1200,
    "r05": 1500, "r06": 1500, "r07": 1500, "r08": 1500,
    "r09":  500, "r10":  500, "r11":  700, "r12":  700,
    "r13": 1000, "r14": 1000, "r15":  900, "r16":  900,
}

# Fleet constraint: each route-time consumes one bus-day of fleet capacity.
# Sized so the problem is feasible (12 required pairs + margin for additional
# high-value route-times that exceed minimum coverage).
AVAILABLE_BUSES = 14

# Minimum service coverage: for each (origin, destination) pair, at least
# this many route-times per day must be scheduled. This is a service-level
# commitment to customers (and, for routes crossing state lines, often a
# regulatory requirement).
MINIMUM_COVERAGE = {
    ("Dallas", "Austin"):        1,
    ("Austin", "Dallas"):        1,
    ("Dallas", "Houston"):       1,
    ("Houston", "Dallas"):       1,
    ("Austin", "San Antonio"):   1,
    ("San Antonio", "Austin"):   1,
    ("Houston", "San Antonio"):  1,
    ("San Antonio", "Houston"):  1,
    ("Dallas", "Oklahoma City"): 1,
    ("Oklahoma City", "Dallas"): 1,
    ("Austin", "Houston"):       1,
    ("Houston", "Austin"):       1,
}

# Driver / departure-hour constraint: only so many drivers available
# to depart in any given hour window (limited terminal / dispatcher
# capacity). Grouped into 4-hour windows for simplicity.
HOUR_WINDOW_CAPACITY = {
    "morning":   6,   # 6:00 - 11:59
    "afternoon": 6,   # 12:00 - 17:59
    "evening":   3,   # 18:00 - 23:59
}


def hour_window(hour):
    if 6 <= hour < 12:
        return "morning"
    elif 12 <= hour < 18:
        return "afternoon"
    else:
        return "evening"


# Penalty weights — tuned so constraint violations always cost more than
# any realistic objective improvement. For a real QUBO these would be
# tuned empirically against held-out data.
P_COVERAGE    = 10000.0   # minimum coverage is a hard requirement
P_FLEET       =  3000.0   # fleet limit — strong enforcement
P_HOUR_WINDOW =  2000.0   # hour-window capacity is operational
W_PROFIT      =     1.0   # objective: maximize revenue - cost


# ----------------------------------------------------------------------
# Step 2 — Build the QUBO
# ----------------------------------------------------------------------
# Binary variable x[r] = 1 if route-time r is scheduled, 0 otherwise.
# Total variables = number of candidate route-times.

def build_network_schedule_bqm():
    bqm = dimod.BinaryQuadraticModel("BINARY")

    # Create all decision variables with zero bias to start.
    for route_id in CANDIDATE_ROUTES:
        bqm.add_variable(route_id, 0.0)

    # --- Objective: maximize (revenue - cost) ---
    # D-Wave minimizes energy, so we negate: linear bias = -(revenue - cost).
    # A route with positive margin gets a negative bias (favors x=1).
    # A route with negative margin gets a positive bias (favors x=0).
    for route_id in CANDIDATE_ROUTES:
        margin = EXPECTED_REVENUE[route_id] - OPERATING_COST[route_id]
        bqm.add_linear(route_id, -W_PROFIT * margin)

    # --- Constraint: minimum coverage per city pair ---
    # For each (origin, dest) pair with minimum k, enforce sum_r x[r] >= k
    # where the sum is over route-times serving that pair.
    #
    # Encoded as a penalty: if sum_r x[r] < k, penalize; if >= k, zero cost.
    # Standard QUBO trick for "at least k" constraints: penalize the
    # complement as a squared shortfall.
    #
    # Implementation: add slack via penalty P * (k - sum_r x[r])^2
    # when the shortfall is positive, and zero otherwise. For k=1 specifically,
    # this simplifies to P * (1 - sum_r x[r])^2 IF sum < 1, else 0. Since
    # QUBOs can't express conditional penalties directly, we use
    # P * (1 - sum_r x[r] - slack)^2 with a slack variable, OR for k=1 we
    # can use the simpler form: P * prod(1 - x[r]) for r serving the pair.
    # That equals P iff all x[r] = 0, else 0 — exactly the penalty we want.
    #
    # For a quadratic model, we expand prod(1 - x_r) only for pairs;
    # for larger k we would use slack variables. For this POC all minima
    # are 1, so we use the product form approximated to quadratic order:
    #   P * (1 - sum_r x[r] + sum_{r<r'} x[r]*x[r']) for small route counts.
    # For safety on this small problem, we use the exact linear form:
    #   P * (1 - sum_r x[r])^2
    # which for k=1 correctly penalizes zero-coverage but also mildly
    # rewards over-coverage (which the fleet constraint then pulls back on).
    for (origin, dest), minimum in MINIMUM_COVERAGE.items():
        serving_routes = [
            r for r, (o, d, _) in CANDIDATE_ROUTES.items()
            if o == origin and d == dest
        ]
        if not serving_routes:
            continue

        # Expand P * (k - sum_r x[r])^2
        # = P * (k^2 - 2k*sum_r x[r] + (sum_r x[r])^2)
        # = P * (k^2 - 2k*sum_r x[r] + sum_r x[r]^2 + 2*sum_{r<r'} x[r]*x[r'])
        # = P * (k^2 - 2k*sum_r x[r] + sum_r x[r] + 2*sum_{r<r'} x[r]*x[r'])
        #   (since x^2 = x for binary)
        # = P * (k^2 + (1 - 2k)*sum_r x[r] + 2*sum_{r<r'} x[r]*x[r'])
        k = minimum
        linear_coef = P_COVERAGE * (1 - 2 * k)
        quadratic_coef = 2 * P_COVERAGE

        for r in serving_routes:
            bqm.add_linear(r, linear_coef)
        for i, r1 in enumerate(serving_routes):
            for r2 in serving_routes[i+1:]:
                bqm.add_quadratic(r1, r2, quadratic_coef)
        # The k^2 constant doesn't affect argmin, so we skip it.

    # --- Constraint: fleet capacity (soft, slack-variable form) ---
    # Real-world "at most N" constraints must use slack variables.
    # A plain (sum_r x_r - N)^2 penalty is symmetric and wrongly penalizes
    # under-capacity, which pulls against coverage requirements.
    #
    # Correct form: introduce slack s_0 ... s_{N-1} binary variables,
    # enforce sum_r x_r + sum_i s_i = N with a squared-equality penalty.
    # The solver will freely set slacks to absorb any unused capacity.
    N = AVAILABLE_BUSES
    all_routes = list(CANDIDATE_ROUTES)
    fleet_slacks = [f"fleet_slack_{i}" for i in range(N)]
    for s in fleet_slacks:
        bqm.add_variable(s, 0.0)

    # Penalty: P * (sum_r x_r + sum_i s_i - N)^2
    # Expand over the union of route vars and slack vars.
    fleet_vars = all_routes + fleet_slacks
    fleet_linear_coef = P_FLEET * (1 - 2 * N)
    fleet_quadratic_coef = 2 * P_FLEET

    for v in fleet_vars:
        bqm.add_linear(v, fleet_linear_coef)
    for i, v1 in enumerate(fleet_vars):
        for v2 in fleet_vars[i+1:]:
            bqm.add_quadratic(v1, v2, fleet_quadratic_coef)

    # --- Constraint: hour-window capacity (slack-variable form) ---
    for window, capacity in HOUR_WINDOW_CAPACITY.items():
        routes_in_window = [
            r for r, (_, _, hour) in CANDIDATE_ROUTES.items()
            if hour_window(hour) == window
        ]
        if not routes_in_window:
            continue

        C = capacity
        window_slacks = [f"{window}_slack_{i}" for i in range(C)]
        for s in window_slacks:
            bqm.add_variable(s, 0.0)

        window_vars = routes_in_window + window_slacks
        w_linear_coef = P_HOUR_WINDOW * (1 - 2 * C)
        w_quadratic_coef = 2 * P_HOUR_WINDOW

        for v in window_vars:
            bqm.add_linear(v, w_linear_coef)
        for i, v1 in enumerate(window_vars):
            for v2 in window_vars[i+1:]:
                bqm.add_quadratic(v1, v2, w_quadratic_coef)

    return bqm


# ----------------------------------------------------------------------
# Step 3 — Submit to D-Wave and interpret results
# ----------------------------------------------------------------------
def solve_on_dwave(bqm, num_reads=1000):
    """Submit the BQM to D-Wave Advantage via Leap and return the sampleset."""
    from dwave.system import DWaveSampler, EmbeddingComposite
    sampler = EmbeddingComposite(DWaveSampler())
    sampleset = sampler.sample(
        bqm,
        num_reads=num_reads,
        label="SQS POC - Greyhound network schedule optimization",
    )
    return sampleset


def interpret_solution(sample):
    """Convert the bitstring sample into a scheduling decision."""
    scheduled = [r for r in CANDIDATE_ROUTES if sample[r] == 1]
    dropped = [r for r in CANDIDATE_ROUTES if sample[r] == 0]
    return scheduled, dropped


def evaluate_solution(scheduled):
    """Compute financial and compliance metrics for a scheduling decision."""
    total_revenue = sum(EXPECTED_REVENUE[r] for r in scheduled)
    total_cost = sum(OPERATING_COST[r] for r in scheduled)
    net_profit = total_revenue - total_cost

    # Coverage check
    coverage = {}
    for (origin, dest), minimum in MINIMUM_COVERAGE.items():
        count = sum(
            1 for r in scheduled
            if CANDIDATE_ROUTES[r][0] == origin and CANDIDATE_ROUTES[r][1] == dest
        )
        coverage[(origin, dest)] = (count, minimum, count >= minimum)

    # Fleet check
    fleet_used = len(scheduled)
    fleet_ok = fleet_used <= AVAILABLE_BUSES

    # Hour-window check
    window_counts = {w: 0 for w in HOUR_WINDOW_CAPACITY}
    for r in scheduled:
        _, _, hour = CANDIDATE_ROUTES[r]
        window_counts[hour_window(hour)] += 1
    window_status = {
        w: (window_counts[w], cap, window_counts[w] <= cap)
        for w, cap in HOUR_WINDOW_CAPACITY.items()
    }

    return {
        "total_revenue": total_revenue,
        "total_cost": total_cost,
        "net_profit": net_profit,
        "coverage": coverage,
        "fleet_used": fleet_used,
        "fleet_ok": fleet_ok,
        "window_status": window_status,
    }


def print_report(scheduled, dropped, metrics, energy):
    print(f"Solution energy: {energy:.2f}")
    print()

    print("Scheduled route-times:")
    for r in scheduled:
        o, d, h = CANDIDATE_ROUTES[r]
        rev = EXPECTED_REVENUE[r]
        cost = OPERATING_COST[r]
        margin = rev - cost
        print(f"  {r}: {o:<14} -> {d:<14}  dep {h:02d}:00   "
              f"rev ${rev:>5}  cost ${cost:>5}  margin ${margin:+5}")
    print()

    print("Dropped route-times (not operated today):")
    for r in dropped:
        o, d, h = CANDIDATE_ROUTES[r]
        margin = EXPECTED_REVENUE[r] - OPERATING_COST[r]
        print(f"  {r}: {o:<14} -> {d:<14}  dep {h:02d}:00   "
              f"margin ${margin:+5}")
    print()

    print("-" * 70)
    print(f"Total revenue:    ${metrics['total_revenue']:>7,}")
    print(f"Total cost:       ${metrics['total_cost']:>7,}")
    print(f"Net profit:       ${metrics['net_profit']:>7,}")
    print()

    print(f"Fleet used: {metrics['fleet_used']}/{AVAILABLE_BUSES}  "
          f"{'OK' if metrics['fleet_ok'] else 'OVER FLEET LIMIT'}")
    print()

    print("Hour-window utilization:")
    for w, (count, cap, ok) in metrics["window_status"].items():
        status = "OK" if ok else "OVER CAPACITY"
        print(f"  {w:<10} {count}/{cap}  {status}")
    print()

    violations = [
        (o, d, c, m) for (o, d), (c, m, ok) in metrics["coverage"].items()
        if not ok
    ]
    if violations:
        print("COVERAGE VIOLATIONS:")
        for o, d, c, m in violations:
            print(f"  {o} -> {d}: scheduled {c}, minimum required {m}")
    else:
        print("All city-pair coverage minimums met.")


# ----------------------------------------------------------------------
# Step 4 — Main entry point
# ----------------------------------------------------------------------
if __name__ == "__main__":
    print("=" * 70)
    print("SQS Proof of Concept — Greyhound Network Schedule Optimization")
    print("=" * 70)
    print(f"Cities: {len(CITIES)}")
    print(f"Candidate route-times: {len(CANDIDATE_ROUTES)}")
    print(f"City-pair coverage requirements: {len(MINIMUM_COVERAGE)}")
    print(f"Available buses: {AVAILABLE_BUSES}")
    print(f"Decision variables: {len(CANDIDATE_ROUTES)}")
    print()

    bqm = build_network_schedule_bqm()
    print(f"BQM built: {len(bqm.variables)} variables, "
          f"{len(bqm.quadratic)} quadratic interactions")
    print()

    print("Submitting to D-Wave Advantage via Leap...")
    sampleset = solve_on_dwave(bqm, num_reads=1000)
    print("Samples received.")
    print()

    best = sampleset.first
    scheduled, dropped = interpret_solution(best.sample)
    metrics = evaluate_solution(scheduled)

    print("Best schedule found:")
    print("-" * 70)
    print_report(scheduled, dropped, metrics, best.energy)
