# SQS Proof of Concept — Greyhound Network Schedule Optimization

Your second-stage onboarding exercise — a meaningful step up in complexity
from the Republic Services POC.

## What this is

A small-scale network schedule optimization problem. For a regional
Greyhound subnetwork (5 cities, 16 candidate route-times), the code
decides which route-times to actually operate today, subject to:

- Minimum service coverage per city pair (12 directed pairs, 1 minimum each)
- Fleet availability (14 buses)
- Hour-window capacity (6 morning, 6 afternoon, 3 evening departures)
- Objective: maximize revenue minus operating cost

This is structurally different from the Republic Services POC. Republic
was "pack N items into K bins." Greyhound network scheduling is
"select a subset of candidate services subject to coverage and resource
constraints" — a set cover + knapsack hybrid.

## Scope disclaimer (important)

Real Greyhound network scheduling involves 200+ cities, thousands of
candidate route-times, multi-day tour compositions, continuous demand
curves, and federal hour-of-service rules. No QUBO formulation —
quantum or classical — solves the full problem in one pass. SQS's
approach is to decompose the network into regional subnetworks of
the size modeled here, solve each, and compose the results.

This POC demonstrates the core QUBO pattern at a size that runs on
D-Wave's direct QPU sampler. Production work in Q2 uses D-Wave's
hybrid CQM solver for larger regional instances.

## What's in here

- `sqs_greyhound_network_poc.py` — the main POC. Formulates the QUBO,
  submits to D-Wave Advantage via Leap, interprets results.
- `sqs_greyhound_classical_validator.py` — runs the same QUBO on
  classical simulated annealing. Use this for rapid iteration.

## Setup

```bash
pip install dwave-ocean-sdk
dwave setup        # configures your Leap API token (one-time)
```

## Run order

**Step 1** — Classical validation (no Leap required):

```bash
python sqs_greyhound_classical_validator.py
```

Expected output: 12 route-times scheduled, all coverage minimums met,
fleet at 12/14, all hour-windows within capacity, net profit ~$6,650.

**Step 2** — Quantum execution on D-Wave hardware:

```bash
python sqs_greyhound_network_poc.py
```

Expected output: Same or better solution, with sampleset diagnostics
for the Q2 benchmark report.

## Key concepts introduced

### Slack variables for "at most N" constraints

The Republic Services POC used a simple squared-penalty for capacity.
That approach is WRONG for this problem because it symmetrically
penalizes both over- and under-capacity, which pulls against the
coverage requirement.

The correct approach, demonstrated here, is **slack variables**:

```
sum_r x_r + sum_i s_i = N
```

Introduce N binary slack variables. The solver freely assigns them
to absorb unused capacity, so under-capacity incurs no penalty but
over-capacity is still forbidden. This is a fundamental QUBO
technique your engineer will use constantly.

### Set-cover structure

The coverage constraint (`each city pair served at least once`) is a
classic set-cover subproblem. The quadratic expansion of
`P * (k - sum x)^2` encodes "at least k" when paired with a positive
objective that rewards scheduling profitable routes.

### Decomposition as the real-world strategy

The "scope disclaimer" above is not just CYA — it's the honest
technical story. When SQS talks to Greyhound's revenue management
team, the first question will be "how do you handle our full network?"
The answer is "we decompose by region and solve regionally, then
optimize the inter-regional connections classically." That answer
requires us to prove we can solve the regional problem well, which
is what this POC does.

## Tuning the penalty weights

The penalties in `sqs_greyhound_network_poc.py` are:

```python
P_COVERAGE    = 10000.0   # hard requirement
P_FLEET       =  3000.0   # operational constraint
P_HOUR_WINDOW =  2000.0   # operational constraint
W_PROFIT      =     1.0   # objective
```

Tuning rule of thumb: every penalty must exceed the largest
possible objective gain from violating that constraint. With max
margin per route = $1,300, penalty of 3,000 for fleet overrun
means violating fleet to schedule one more route costs 3,000
but gains 1,300 — the solver will respect the constraint.

If the engineer changes the problem (different demand forecasts,
different fleet size), these weights must be re-tuned.

## Scaling to production

This POC is 16 decision variables + 23 slack variables = 39 variables.
D-Wave's direct QPU sampler (`DWaveSampler + EmbeddingComposite`)
handles this comfortably.

A full Greyhound regional subnetwork might be 500+ route-times with
hundreds of coverage pairs — too large for direct QPU embedding.
Q2 work switches to D-Wave's `LeapHybridCQMSampler`, which handles
up to 2 million variables and 100,000 constraints.

The QUBO formulation pattern transfers directly. The CQM API lets
you express constraints more naturally (not as penalties), but the
underlying mathematical structure is the same.
