"""
SQS Proof of Concept — Republic Services Route Assignment (Small Scale)
========================================================================

A minimal, runnable example showing how SanTed Quantum Scheduling (SQS)
formulates a real fleet routing problem as a QUBO and solves it on D-Wave
quantum annealing hardware via the Leap cloud platform.

Business problem:
  Republic Services has 6 stops to service this morning and 2 available
  trucks. Each stop has a pickup load (in tons). Each truck has a capacity.
  Assign every stop to exactly one truck, such that:
    - Every stop is serviced exactly once
    - Neither truck exceeds its capacity
    - Total workload is balanced across trucks (minimize imbalance)

This is the smallest meaningful version of the Republic Services daily
routing problem. Scale drops linearly with variable count — production
runs use D-Wave's hybrid CQM solver for 100+ stops per route.

Requirements:
  pip install dwave-ocean-sdk
  dwave setup     (one-time: configures your Leap API token)

Expected runtime: ~5 seconds on D-Wave Advantage QPU via Leap.
Expected cost on paid tier: <$0.50 per run.
Expected cost on LaunchPad / free trial: $0.
"""

import dimod


# ----------------------------------------------------------------------
# Step 1 — Define the business problem
# ----------------------------------------------------------------------
# Six stops on a morning route. Load is in tons (a realistic Republic
# Services commercial route ranges from ~0.5 to ~4 tons per stop).
STOPS = {
    "stop_0": 2.5,
    "stop_1": 1.8,
    "stop_2": 3.0,
    "stop_3": 1.2,
    "stop_4": 2.0,
    "stop_5": 1.5,
}

# Two trucks available, each with a capacity limit (in tons).
# Total load = 12.0 tons, capacities chosen so a feasible balanced
# assignment exists but isn't obvious.
TRUCKS = {
    "truck_A": 7.0,
    "truck_B": 7.0,
}

# Penalty weights — tuned so that constraint violations cost more
# than any realistic objective improvement. Standard QUBO practice.
P_ASSIGNMENT = 10.0   # must assign each stop exactly once
P_CAPACITY   = 5.0    # must not exceed truck capacity
W_BALANCE    = 1.0    # minimize workload imbalance


# ----------------------------------------------------------------------
# Step 2 — Build the QUBO
# ----------------------------------------------------------------------
# Binary variable x[(stop, truck)] = 1 if stop is assigned to truck.
# Total variables = len(STOPS) * len(TRUCKS) = 6 * 2 = 12.

def build_route_assignment_bqm():
    bqm = dimod.BinaryQuadraticModel("BINARY")

    # Create all variables first (ensures they exist even with zero bias).
    variables = {}
    for stop in STOPS:
        for truck in TRUCKS:
            v = f"{stop}__{truck}"
            variables[(stop, truck)] = v
            bqm.add_variable(v, 0.0)

    # --- Constraint 1: each stop assigned to exactly one truck ---
    # Enforced by the penalty: P * (sum_t x[s,t] - 1)^2
    # Expanded: P * (sum_t x[s,t]^2 + 2*sum_{t<t'} x[s,t]*x[s,t'] - 2*sum_t x[s,t] + 1)
    # For binary x, x^2 = x, so: P * (sum_t x[s,t] + 2*sum_{t<t'} x[s,t]*x[s,t'] - 2*sum_t x[s,t])
    #                         = P * (-sum_t x[s,t] + 2*sum_{t<t'} x[s,t]*x[s,t'])
    for stop in STOPS:
        trucks_list = list(TRUCKS)
        for truck in trucks_list:
            bqm.add_linear(variables[(stop, truck)], -P_ASSIGNMENT)
        for i, t1 in enumerate(trucks_list):
            for t2 in trucks_list[i+1:]:
                bqm.add_quadratic(
                    variables[(stop, t1)],
                    variables[(stop, t2)],
                    2.0 * P_ASSIGNMENT,
                )

    # --- Constraint 2: truck capacity ---
    # Soft penalty: P * max(0, sum_s load[s]*x[s,t] - capacity[t])^2
    # We implement via a quadratic penalty that's active across the
    # full load expression. This is an approximation that works well
    # for small problems; production code uses slack variables.
    for truck, capacity in TRUCKS.items():
        # Expand (sum_s L_s * x[s,t] - C)^2
        # = sum_s L_s^2 * x[s,t]  (since x^2 = x for binary)
        #   + 2*sum_{s<s'} L_s*L_s' * x[s,t]*x[s',t]
        #   - 2*C * sum_s L_s * x[s,t]
        #   + C^2
        stops_list = list(STOPS)
        for stop in stops_list:
            load = STOPS[stop]
            bqm.add_linear(
                variables[(stop, truck)],
                P_CAPACITY * (load * load - 2.0 * capacity * load),
            )
        for i, s1 in enumerate(stops_list):
            for s2 in stops_list[i+1:]:
                l1, l2 = STOPS[s1], STOPS[s2]
                bqm.add_quadratic(
                    variables[(s1, truck)],
                    variables[(s2, truck)],
                    2.0 * P_CAPACITY * l1 * l2,
                )
        # Note: the constant C^2 term is dropped — it doesn't affect
        # the argmin, only the absolute energy.

    # --- Objective: balance workload across trucks ---
    # Minimize (load_A - load_B)^2 — favors even distribution.
    # For 2 trucks: (sum_s L_s*x[s,A] - sum_s L_s*x[s,B])^2
    trucks_list = list(TRUCKS)
    if len(trucks_list) == 2:
        tA, tB = trucks_list
        stops_list = list(STOPS)
        # Diagonal terms: L_s^2 * x[s,A] + L_s^2 * x[s,B]
        for stop in stops_list:
            load = STOPS[stop]
            bqm.add_linear(variables[(stop, tA)], W_BALANCE * load * load)
            bqm.add_linear(variables[(stop, tB)], W_BALANCE * load * load)
        # Cross terms within same truck: +2*L_s*L_s'
        for i, s1 in enumerate(stops_list):
            for s2 in stops_list[i+1:]:
                l1, l2 = STOPS[s1], STOPS[s2]
                bqm.add_quadratic(variables[(s1, tA)], variables[(s2, tA)], 2.0 * W_BALANCE * l1 * l2)
                bqm.add_quadratic(variables[(s1, tB)], variables[(s2, tB)], 2.0 * W_BALANCE * l1 * l2)
        # Cross terms between trucks: -2*L_s*L_s'
        for s1 in stops_list:
            for s2 in stops_list:
                l1, l2 = STOPS[s1], STOPS[s2]
                bqm.add_quadratic(variables[(s1, tA)], variables[(s2, tB)], -2.0 * W_BALANCE * l1 * l2)

    return bqm, variables


# ----------------------------------------------------------------------
# Step 3 — Submit to D-Wave and interpret results
# ----------------------------------------------------------------------
def solve_on_dwave(bqm, variables, num_reads=1000):
    """Submit the BQM to D-Wave Advantage via Leap and return the best assignment."""
    from dwave.system import DWaveSampler, EmbeddingComposite
    sampler = EmbeddingComposite(DWaveSampler())
    sampleset = sampler.sample(
        bqm,
        num_reads=num_reads,
        label="SQS POC - Republic Services route assignment",
    )
    return sampleset


def interpret_solution(sample, variables):
    """Convert the bitstring sample into a human-readable truck assignment."""
    assignment = {truck: [] for truck in TRUCKS}
    unassigned = []
    double_assigned = []

    for stop in STOPS:
        assigned_trucks = [
            truck for truck in TRUCKS
            if sample[variables[(stop, truck)]] == 1
        ]
        if len(assigned_trucks) == 0:
            unassigned.append(stop)
        elif len(assigned_trucks) > 1:
            double_assigned.append((stop, assigned_trucks))
            assignment[assigned_trucks[0]].append(stop)
        else:
            assignment[assigned_trucks[0]].append(stop)

    return assignment, unassigned, double_assigned


def print_report(assignment, unassigned, double_assigned, energy):
    print(f"Solution energy: {energy:.2f}")
    print()
    for truck, stops in assignment.items():
        total_load = sum(STOPS[s] for s in stops)
        capacity = TRUCKS[truck]
        utilization = (total_load / capacity) * 100 if capacity > 0 else 0
        status = "OK" if total_load <= capacity else "OVER CAPACITY"
        print(f"  {truck}  (capacity {capacity} tons):")
        for s in stops:
            print(f"    - {s} ({STOPS[s]} tons)")
        print(f"    total: {total_load:.1f} tons  ({utilization:.0f}% utilization)  {status}")
        print()

    if unassigned:
        print(f"  WARNING: unassigned stops: {unassigned}")
    if double_assigned:
        print(f"  WARNING: double-assigned stops: {double_assigned}")


# ----------------------------------------------------------------------
# Step 4 — Main entry point
# ----------------------------------------------------------------------
if __name__ == "__main__":
    print("=" * 70)
    print("SQS Proof of Concept — Republic Services Route Assignment")
    print("=" * 70)
    print(f"Stops to service: {len(STOPS)}")
    print(f"Total load: {sum(STOPS.values()):.1f} tons")
    print(f"Trucks available: {len(TRUCKS)} "
          f"(total capacity: {sum(TRUCKS.values()):.1f} tons)")
    print(f"Variables in QUBO: {len(STOPS) * len(TRUCKS)}")
    print()

    bqm, variables = build_route_assignment_bqm()
    print(f"BQM built: {len(bqm.variables)} variables, "
          f"{len(bqm.quadratic)} quadratic interactions")
    print()

    print("Submitting to D-Wave Advantage via Leap...")
    sampleset = solve_on_dwave(bqm, variables, num_reads=1000)
    print("Samples received.")
    print()

    # The best sample has the lowest energy — standard D-Wave pattern.
    best = sampleset.first
    assignment, unassigned, double_assigned = interpret_solution(
        best.sample, variables
    )

    print("Best assignment found:")
    print("-" * 70)
    print_report(assignment, unassigned, double_assigned, best.energy)

    # Optional: show the top 3 distinct solutions for dispatcher review.
    print("Top 3 distinct solutions (by frequency):")
    print("-" * 70)
    seen_energies = set()
    count = 0
    for sample, energy, occ in sampleset.data(
        fields=["sample", "energy", "num_occurrences"]
    ):
        rounded = round(energy, 2)
        if rounded in seen_energies:
            continue
        seen_energies.add(rounded)
        count += 1
        print(f"\nSolution #{count} (energy={energy:.2f}, occurred {occ} times):")
        a, u, d = interpret_solution(sample, variables)
        for truck, stops in a.items():
            total_load = sum(STOPS[s] for s in stops)
            print(f"  {truck}: {stops}  ({total_load:.1f}t)")
        if count >= 3:
            break
