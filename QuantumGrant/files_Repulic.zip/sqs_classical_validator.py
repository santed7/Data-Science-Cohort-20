"""
SQS Proof of Concept — Classical Validator
===========================================

Runs the EXACT SAME QUBO as sqs_republic_route_poc.py, but using D-Wave's
classical simulated annealing sampler instead of the quantum hardware.

Purpose:
  - Validate QUBO formulation correctness BEFORE burning quantum compute
  - Run offline (no Leap account required) for rapid iteration
  - Establish the classical baseline for the Q2 benchmark milestone

Requirements:
  pip install dwave-ocean-sdk

This uses neal.SimulatedAnnealingSampler — a pure-Python classical solver
that implements the same sampling interface as DWaveSampler. If the QUBO
is formulated correctly, this solver will find the same optimal solutions
as the quantum hardware (just slower on large problems).
"""

from dwave.samplers import SimulatedAnnealingSampler
from sqs_republic_route_poc import (
    STOPS,
    TRUCKS,
    build_route_assignment_bqm,
    interpret_solution,
    print_report,
)


def solve_classical(bqm, num_reads=1000):
    """Run the same BQM on classical simulated annealing."""
    sampler = SimulatedAnnealingSampler()
    sampleset = sampler.sample(bqm, num_reads=num_reads)
    return sampleset


if __name__ == "__main__":
    print("=" * 70)
    print("SQS POC — Classical Validator (D-Wave NEAL simulated annealing)")
    print("=" * 70)
    print(f"Stops: {len(STOPS)}, Trucks: {len(TRUCKS)}, "
          f"Total load: {sum(STOPS.values()):.1f}t")
    print()

    bqm, variables = build_route_assignment_bqm()
    print(f"BQM: {len(bqm.variables)} variables, "
          f"{len(bqm.quadratic)} quadratic interactions")
    print()

    print("Running classical simulated annealing (no Leap required)...")
    sampleset = solve_classical(bqm, num_reads=1000)
    print(f"Completed {len(sampleset)} samples.")
    print()

    best = sampleset.first
    assignment, unassigned, double_assigned = interpret_solution(
        best.sample, variables
    )

    print("Best assignment (classical):")
    print("-" * 70)
    print_report(assignment, unassigned, double_assigned, best.energy)

    print()
    print("Next step: run sqs_republic_route_poc.py against D-Wave hardware.")
    print("Compare: quantum should find the same or better solutions.")
