# SQS Proof of Concept — Republic Services Route Optimization

Your day-one onboarding exercise.

## What this is

This is the smallest possible version of SanTed Quantum Scheduling's
production routing problem. Six stops, two trucks, tons of load per stop,
capacity limits, balanced workload objective. Twelve binary variables.

The purpose is to prove — on real D-Wave quantum hardware — that SQS's
QUBO formulation approach actually works. Once this runs correctly,
you scale the same pattern to 100-stop Republic Services routes and
200+ stop Greyhound multi-segment schedules using D-Wave's hybrid
CQM solver.

## What's in here

- `sqs_republic_route_poc.py` — the main POC. Formulates the QUBO,
  submits to D-Wave Advantage via Leap, interprets results.
- `sqs_classical_validator.py` — runs the SAME QUBO on classical
  simulated annealing. Use this to iterate quickly without burning
  quantum compute time.

## Setup

```bash
pip install dwave-ocean-sdk
dwave setup        # configures your Leap API token (one-time)
```

For Leap access:
1. Free Trial: sign up at https://cloud.dwavesys.com/leap/signup
2. LaunchPad: apply at https://www.dwavequantum.com/quantum-launchpad/
   (SQS strategy document covers this)

## Run order

**Step 1** — Validate the QUBO classically (no Leap required):

```bash
python sqs_classical_validator.py
```

Expected output: Both trucks at 6.0 tons each (balanced), no capacity
violations, every stop assigned. If you see unassigned stops, double
assignments, or capacity overflow, the QUBO needs tuning — adjust the
penalty weights `P_ASSIGNMENT`, `P_CAPACITY`, `W_BALANCE` in
`sqs_republic_route_poc.py` and try again.

**Step 2** — Run on D-Wave quantum hardware:

```bash
python sqs_republic_route_poc.py
```

Expected output: The same or better solution, plus the top 3 distinct
answers D-Wave found across 1,000 samples. This is the data we'll
report in the Q2 benchmark milestone.

## What to watch for

- **Solution energy** — lower is better. The lowest-energy solutions
  satisfy the constraints and minimize workload imbalance.
- **Sample diversity** — D-Wave returns many samples. Good QUBO
  formulations cluster most samples around the optimal solution.
  Wide energy spread means the problem is under-constrained or the
  penalties are mis-tuned.
- **Chain breaks** — shown in the `chain_.` column of sampleset
  output. Non-zero values mean the minor-embedding onto the QPU's
  physical qubits is straining. For this small a problem you should
  see zero chain breaks.

## Scaling plan

This POC uses `DWaveSampler + EmbeddingComposite` — D-Wave's direct
QPU sampling path. Fine for up to ~200 variables, which covers toy
problems but not production fleet sizes.

For real Republic Services data (100+ stops, 10+ trucks, time windows,
driver hour constraints), the next step is `LeapHybridCQMSampler` with
the Constrained Quadratic Model. That's Q2 work. But this POC is the
foundation — the QUBO formulation skills transfer directly.

## Reference

This code follows the workflow described in D-Wave's official
documentation: https://docs.dwavequantum.com/ — see "Basic Workflow:
Formulation and Sampling" for the canonical pattern.

The main difference: D-Wave's example uses `dimod.generators.combinations`
for a toy "select k of n" problem. We've hand-built the BQM because our
real constraints (capacity, balance) aren't in the generators library.
Understanding how to hand-build the BQM is the core skill SQS needs.
